"use client"

import { useState } from "react"
import { AppSidebar } from "@/components/app-sidebar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { 
  X, 
  ChevronDown, 
  Gift,
  FileText,
  FolderOpen,
  Users,
  Wifi,
  TrendingUp,
  Megaphone,
  Coffee,
  Plus,
  Trash2,
  Search,
  Eye,
  Edit,
  MoreHorizontal,
  Bell,
  Settings,
  LogOut,
  User,
  Check,
  AlertCircle
} from "lucide-react"
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  ResponsiveContainer,
  Tooltip,
} from "recharts"
import { toast } from "sonner"

// Chart data
const chartData = [
  { name: "1", value: 40 },
  { name: "2", value: 45 },
  { name: "3", value: 42 },
  { name: "4", value: 55 },
  { name: "5", value: 58 },
  { name: "6", value: 65 },
  { name: "7", value: 70 },
  { name: "8", value: 75 },
  { name: "9", value: 80 },
  { name: "10", value: 85 },
  { name: "11", value: 90 },
  { name: "12", value: 88 },
  { name: "13", value: 92 },
  { name: "14", value: 95 },
  { name: "15", value: 90 },
  { name: "16", value: 93 },
  { name: "17", value: 95 },
  { name: "18", value: 98 },
  { name: "19", value: 100 },
  { name: "20", value: 101 },
]

// Types
interface Activity {
  id: number
  user: string
  action: string
  date: string
}

interface Announcement {
  id: number
  user: string
  avatar: string
  date: string
  message: string
}

interface Citizen {
  id: number
  name: string
  status: string
  casier: boolean
  lastSeen: string
}

interface Complaint {
  id: number
  plaintiff: string
  defendant: string
  type: string
  status: string
  date: string
}

// Initial data
const initialActivities: Activity[] = [
  { id: 1, user: "93", action: "Modification de l'utilisateur 93", date: "il y a 13 minutes" },
  { id: 2, user: "salam", action: "Inscription", date: "il y a environ 1 heure" },
  { id: 3, user: "Jean", action: "Connexion", date: "il y a environ 1 heure" },
  { id: 4, user: "Marie", action: "Ajout de donnees", date: "il y a 1 jour" },
]

const initialAnnouncements: Announcement[] = [
  {
    id: 1,
    user: "lamiraal",
    avatar: "/avatars/lamiraal.jpg",
    date: "10/04/2026 07:53",
    message: "Mes respect, @role, Une operation special est prevue ce samedi 11/04 a 20h15. Rendez-vous au sous-sol, en tenue d'intervention. L'operation sera dirigee par le @user & @user Respectueusement, vos Haut Grades."
  },
  {
    id: 2,
    user: "yazouv",
    avatar: "/avatars/yazouv.jpg",
    date: "09/04/2026 22:47",
    message: "@role Bonsoir, suite au licenciement d'un des deux @role j'en cherche un nouveau. Grade minimum : @role. Ouvrir un ticket #channel -> CATEGORIE RH/SECRETARIAT Mettez dedans vos motivations"
  },
]

const initialCitizens: Citizen[] = [
  { id: 1, name: "Jean Dupont", status: "En ville", casier: true, lastSeen: "il y a 5 minutes" },
  { id: 2, name: "Marie Martin", status: "Hors ligne", casier: false, lastSeen: "il y a 2 heures" },
  { id: 3, name: "Pierre Durant", status: "En ville", casier: true, lastSeen: "il y a 10 minutes" },
  { id: 4, name: "Sophie Bernard", status: "En prison", casier: true, lastSeen: "il y a 1 jour" },
  { id: 5, name: "Lucas Petit", status: "En ville", casier: false, lastSeen: "il y a 30 minutes" },
]

const initialComplaints: Complaint[] = [
  { id: 1, plaintiff: "Jean Dupont", defendant: "Pierre Martin", type: "Vol", status: "En cours", date: "10/04/2026" },
  { id: 2, plaintiff: "Marie Bernard", defendant: "Lucas Petit", type: "Agression", status: "Resolu", date: "09/04/2026" },
  { id: 3, plaintiff: "Sophie Durant", defendant: "Inconnu", type: "Vandalisme", status: "En attente", date: "08/04/2026" },
]

// Custom Tooltip for Chart
const CustomTooltip = ({ active, payload }: { active?: boolean; payload?: Array<{ value: number }> }) => {
  if (active && payload && payload.length) {
    return (
      <div className="rounded-lg border border-border bg-popover px-3 py-2 shadow-lg">
        <p className="text-sm font-semibold text-foreground">{payload[0].value} citoyens</p>
      </div>
    )
  }
  return null
}

// Dashboard Content Component
function DashboardContent() {
  const [activities, setActivities] = useState<Activity[]>(initialActivities)
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [newActivity, setNewActivity] = useState({ user: "", action: "" })

  const handleAddActivity = () => {
    if (newActivity.user && newActivity.action) {
      const activity: Activity = {
        id: Date.now(),
        user: newActivity.user,
        action: newActivity.action,
        date: "a l'instant"
      }
      setActivities([activity, ...activities])
      setNewActivity({ user: "", action: "" })
      setShowAddDialog(false)
      toast.success("Activite ajoutee avec succes")
    }
  }

  const handleDeleteActivity = (id: number) => {
    setActivities(activities.filter(a => a.id !== id))
    toast.success("Activite supprimee")
  }

  const handleClearAll = () => {
    setActivities([])
    toast.success("Toutes les activites ont ete effacees")
  }

  return (
    <div className="flex flex-col gap-6">
      {/* Welcome section */}
      <div className="flex items-center justify-between">
        <div className="flex flex-col gap-1">
          <h1 className="text-3xl font-bold text-white">Bienvenue, Agent</h1>
          <div className="flex items-center gap-2">
            <div className="flex h-6 w-6 items-center justify-center rounded bg-orange-500">
              <span className="text-xs font-bold text-white">ID</span>
            </div>
            <span className="text-muted-foreground">Matricule 93</span>
          </div>
        </div>
        <div className="text-right">
          <p className="text-sm text-muted-foreground">samedi 11 avril 2026</p>
          <p className="text-2xl font-bold text-cyan-400">14:06</p>
        </div>
      </div>

      {/* Stats cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <div className="group cursor-pointer rounded-lg bg-gradient-to-br from-red-600 to-orange-600 p-5 transition-all hover:scale-[1.02] hover:shadow-lg hover:shadow-red-500/20">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-white/80">Casiers aujourd&apos;hui</p>
              <p className="mt-2 text-4xl font-bold text-white">23</p>
              <p className="mt-1 flex items-center gap-1 text-xs text-white/70">
                <TrendingUp className="h-3 w-3 rotate-180" />
                -17.9% vs hier
              </p>
            </div>
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white/20 transition-transform group-hover:scale-110">
              <FileText className="h-5 w-5 text-white" />
            </div>
          </div>
        </div>

        <div className="group cursor-pointer rounded-lg bg-gradient-to-br from-blue-600 to-blue-800 p-5 transition-all hover:scale-[1.02] hover:shadow-lg hover:shadow-blue-500/20">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-white/80">Total Casiers</p>
              <p className="mt-2 text-4xl font-bold text-white">14883</p>
              <p className="mt-1 text-xs text-white/70">Depuis la creation</p>
            </div>
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white/20 transition-transform group-hover:scale-110">
              <FolderOpen className="h-5 w-5 text-white" />
            </div>
          </div>
        </div>

        <div className="group cursor-pointer rounded-lg bg-gradient-to-br from-emerald-500 to-emerald-700 p-5 transition-all hover:scale-[1.02] hover:shadow-lg hover:shadow-emerald-500/20">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-white/80">Total Citoyens</p>
              <p className="mt-2 text-4xl font-bold text-white">9350</p>
              <p className="mt-1 text-xs text-white/70">Base de donnees</p>
            </div>
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white/20 transition-transform group-hover:scale-110">
              <Users className="h-5 w-5 text-white" />
            </div>
          </div>
        </div>

        <div className="group cursor-pointer rounded-lg bg-gradient-to-br from-purple-600 to-purple-800 p-5 transition-all hover:scale-[1.02] hover:shadow-lg hover:shadow-purple-500/20">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-xs font-semibold uppercase tracking-wider text-white/80">Agents en Service</p>
              <p className="mt-2 text-4xl font-bold text-white">10</p>
              <p className="mt-1 text-xs text-white/70">Actuellement connectes</p>
            </div>
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-white/20 transition-transform group-hover:scale-110">
              <Wifi className="h-5 w-5 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Chart and Announcements */}
      <div className="grid gap-6 lg:grid-cols-2">
        <div className="rounded-lg border border-border bg-card p-5">
          <div className="mb-4 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-cyan-400" />
              <h3 className="font-semibold text-white">Citoyens en Ville</h3>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-white">101</p>
              <p className="text-xs text-emerald-400">+7.4% vs precedent</p>
            </div>
          </div>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={chartData}>
                <defs>
                  <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.3}/>
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis 
                  dataKey="name" 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: '#64748b', fontSize: 12 }}
                />
                <YAxis 
                  axisLine={false}
                  tickLine={false}
                  tick={{ fill: '#64748b', fontSize: 12 }}
                  domain={[0, 120]}
                />
                <Tooltip content={<CustomTooltip />} />
                <Area
                  type="monotone"
                  dataKey="value"
                  stroke="#06b6d4"
                  strokeWidth={2}
                  fill="url(#colorValue)"
                  dot={{ fill: '#06b6d4', strokeWidth: 0, r: 3 }}
                  activeDot={{ r: 6, fill: '#06b6d4', stroke: '#fff', strokeWidth: 2 }}
                />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="rounded-lg border border-border bg-card p-5">
          <div className="mb-4 flex items-center gap-2">
            <Megaphone className="h-5 w-5 text-orange-400" />
            <h3 className="font-semibold text-white">Annonces Importantes</h3>
          </div>
          <div className="max-h-72 space-y-4 overflow-y-auto scrollbar-thin">
            {initialAnnouncements.map((announcement) => (
              <div key={announcement.id} className="border-b border-border pb-4 last:border-0 transition-colors hover:bg-muted/30 rounded-lg p-2 -m-2">
                <div className="mb-2 flex items-center gap-3">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={announcement.avatar} />
                    <AvatarFallback className="bg-secondary text-xs">
                      {announcement.user.substring(0, 2).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <span className="font-semibold text-white">{announcement.user}</span>
                    <span className="ml-2 text-xs text-muted-foreground">{announcement.date}</span>
                  </div>
                </div>
                <p className="text-sm leading-relaxed text-muted-foreground">
                  {announcement.message}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Recent Activity Table */}
      <div className="rounded-lg border border-border bg-card p-5">
        <div className="mb-4 flex items-center justify-between">
          <h3 className="font-semibold text-white">Activite recente</h3>
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm" 
              className="gap-1 border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10"
              onClick={() => setShowAddDialog(true)}
            >
              <Plus className="h-4 w-4" />
              Ajouter
            </Button>
            <Button 
              variant="outline" 
              size="sm" 
              className="gap-1 border-red-500/50 text-red-400 hover:bg-red-500/10"
              onClick={handleClearAll}
            >
              <Trash2 className="h-4 w-4" />
              Tout effacer
            </Button>
          </div>
        </div>
        <Table>
          <TableHeader>
            <TableRow className="border-border hover:bg-transparent">
              <TableHead className="text-muted-foreground">Utilisateur</TableHead>
              <TableHead className="text-muted-foreground">Action</TableHead>
              <TableHead className="text-muted-foreground">Date</TableHead>
              <TableHead className="w-10"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {activities.map((activity) => (
              <TableRow key={activity.id} className="border-border hover:bg-muted/30">
                <TableCell className="font-medium text-foreground">{activity.user}</TableCell>
                <TableCell className="text-muted-foreground">{activity.action}</TableCell>
                <TableCell className="text-muted-foreground">{activity.date}</TableCell>
                <TableCell>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    className="h-8 w-8 text-muted-foreground hover:text-red-400"
                    onClick={() => handleDeleteActivity(activity.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
            {activities.length === 0 && (
              <TableRow>
                <TableCell colSpan={4} className="text-center text-muted-foreground py-8">
                  Aucune activite recente
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>

      {/* Add Activity Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle className="text-foreground">Ajouter une activite</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Enregistrez une nouvelle activite dans le journal.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <label className="text-sm text-muted-foreground">Utilisateur</label>
              <Input 
                placeholder="Nom de l'utilisateur" 
                value={newActivity.user}
                onChange={(e) => setNewActivity({ ...newActivity, user: e.target.value })}
                className="bg-background border-border"
              />
            </div>
            <div className="grid gap-2">
              <label className="text-sm text-muted-foreground">Action</label>
              <Input 
                placeholder="Description de l'action" 
                value={newActivity.action}
                onChange={(e) => setNewActivity({ ...newActivity, action: e.target.value })}
                className="bg-background border-border"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>Annuler</Button>
            <Button onClick={handleAddActivity} className="bg-cyan-600 hover:bg-cyan-700">Ajouter</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// Citizens Content Component
function CitizensContent() {
  const [citizens, setCitizens] = useState<Citizen[]>(initialCitizens)
  const [searchTerm, setSearchTerm] = useState("")
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [newCitizen, setNewCitizen] = useState({ name: "", status: "En ville", casier: false })

  const filteredCitizens = citizens.filter(c => 
    c.name.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const handleAddCitizen = () => {
    if (newCitizen.name) {
      const citizen: Citizen = {
        id: Date.now(),
        name: newCitizen.name,
        status: newCitizen.status,
        casier: newCitizen.casier,
        lastSeen: "a l'instant"
      }
      setCitizens([citizen, ...citizens])
      setNewCitizen({ name: "", status: "En ville", casier: false })
      setShowAddDialog(false)
      toast.success("Citoyen ajoute avec succes")
    }
  }

  const handleDeleteCitizen = (id: number) => {
    setCitizens(citizens.filter(c => c.id !== id))
    toast.success("Citoyen supprime")
  }

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { class: string }> = {
      "En ville": { class: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30" },
      "Hors ligne": { class: "bg-gray-500/20 text-gray-400 border-gray-500/30" },
      "En prison": { class: "bg-red-500/20 text-red-400 border-red-500/30" },
    }
    return variants[status] || variants["Hors ligne"]
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white">Gestion des Citoyens</h1>
        <Button onClick={() => setShowAddDialog(true)} className="gap-2 bg-cyan-600 hover:bg-cyan-700">
          <Plus className="h-4 w-4" />
          Nouveau Citoyen
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input 
          placeholder="Rechercher un citoyen..." 
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10 bg-card border-border"
        />
      </div>

      <div className="rounded-lg border border-border bg-card">
        <Table>
          <TableHeader>
            <TableRow className="border-border hover:bg-transparent">
              <TableHead className="text-muted-foreground">Nom</TableHead>
              <TableHead className="text-muted-foreground">Statut</TableHead>
              <TableHead className="text-muted-foreground">Casier</TableHead>
              <TableHead className="text-muted-foreground">Derniere connexion</TableHead>
              <TableHead className="text-right text-muted-foreground">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredCitizens.map((citizen) => (
              <TableRow key={citizen.id} className="border-border hover:bg-muted/30">
                <TableCell className="font-medium text-foreground">{citizen.name}</TableCell>
                <TableCell>
                  <Badge variant="outline" className={getStatusBadge(citizen.status).class}>
                    {citizen.status}
                  </Badge>
                </TableCell>
                <TableCell>
                  {citizen.casier ? (
                    <Badge variant="outline" className="bg-red-500/20 text-red-400 border-red-500/30">Oui</Badge>
                  ) : (
                    <Badge variant="outline" className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">Non</Badge>
                  )}
                </TableCell>
                <TableCell className="text-muted-foreground">{citizen.lastSeen}</TableCell>
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="bg-card border-border">
                      <DropdownMenuItem className="gap-2 cursor-pointer">
                        <Eye className="h-4 w-4" />
                        Voir le profil
                      </DropdownMenuItem>
                      <DropdownMenuItem className="gap-2 cursor-pointer">
                        <Edit className="h-4 w-4" />
                        Modifier
                      </DropdownMenuItem>
                      <DropdownMenuSeparator className="bg-border" />
                      <DropdownMenuItem 
                        className="gap-2 cursor-pointer text-red-400 focus:text-red-400"
                        onClick={() => handleDeleteCitizen(citizen.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                        Supprimer
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle className="text-foreground">Ajouter un citoyen</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Enregistrez un nouveau citoyen dans la base de donnees.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <label className="text-sm text-muted-foreground">Nom complet</label>
              <Input 
                placeholder="Nom du citoyen" 
                value={newCitizen.name}
                onChange={(e) => setNewCitizen({ ...newCitizen, name: e.target.value })}
                className="bg-background border-border"
              />
            </div>
            <div className="grid gap-2">
              <label className="text-sm text-muted-foreground">Statut</label>
              <select 
                value={newCitizen.status}
                onChange={(e) => setNewCitizen({ ...newCitizen, status: e.target.value })}
                className="flex h-10 w-full rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground"
              >
                <option value="En ville">En ville</option>
                <option value="Hors ligne">Hors ligne</option>
                <option value="En prison">En prison</option>
              </select>
            </div>
            <div className="flex items-center gap-2">
              <input 
                type="checkbox"
                checked={newCitizen.casier}
                onChange={(e) => setNewCitizen({ ...newCitizen, casier: e.target.checked })}
                className="h-4 w-4 rounded border-border"
              />
              <label className="text-sm text-muted-foreground">Possede un casier judiciaire</label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>Annuler</Button>
            <Button onClick={handleAddCitizen} className="bg-cyan-600 hover:bg-cyan-700">Ajouter</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// Complaints Content Component
function ComplaintsContent() {
  const [complaints, setComplaints] = useState<Complaint[]>(initialComplaints)
  const [searchTerm, setSearchTerm] = useState("")
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [newComplaint, setNewComplaint] = useState({ plaintiff: "", defendant: "", type: "Vol" })

  const filteredComplaints = complaints.filter(c => 
    c.plaintiff.toLowerCase().includes(searchTerm.toLowerCase()) ||
    c.defendant.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const handleAddComplaint = () => {
    if (newComplaint.plaintiff && newComplaint.defendant) {
      const complaint: Complaint = {
        id: Date.now(),
        plaintiff: newComplaint.plaintiff,
        defendant: newComplaint.defendant,
        type: newComplaint.type,
        status: "En attente",
        date: new Date().toLocaleDateString('fr-FR')
      }
      setComplaints([complaint, ...complaints])
      setNewComplaint({ plaintiff: "", defendant: "", type: "Vol" })
      setShowAddDialog(false)
      toast.success("Plainte enregistree avec succes")
    }
  }

  const handleResolve = (id: number) => {
    setComplaints(complaints.map(c => c.id === id ? { ...c, status: "Resolu" } : c))
    toast.success("Plainte marquee comme resolue")
  }

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { class: string }> = {
      "En cours": { class: "bg-blue-500/20 text-blue-400 border-blue-500/30" },
      "Resolu": { class: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30" },
      "En attente": { class: "bg-yellow-500/20 text-yellow-400 border-yellow-500/30" },
    }
    return variants[status] || variants["En attente"]
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-white">Gestion des Plaintes</h1>
        <Button onClick={() => setShowAddDialog(true)} className="gap-2 bg-cyan-600 hover:bg-cyan-700">
          <Plus className="h-4 w-4" />
          Nouvelle Plainte
        </Button>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input 
          placeholder="Rechercher une plainte..." 
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10 bg-card border-border"
        />
      </div>

      <div className="rounded-lg border border-border bg-card">
        <Table>
          <TableHeader>
            <TableRow className="border-border hover:bg-transparent">
              <TableHead className="text-muted-foreground">Plaignant</TableHead>
              <TableHead className="text-muted-foreground">Accuse</TableHead>
              <TableHead className="text-muted-foreground">Type</TableHead>
              <TableHead className="text-muted-foreground">Statut</TableHead>
              <TableHead className="text-muted-foreground">Date</TableHead>
              <TableHead className="text-right text-muted-foreground">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredComplaints.map((complaint) => (
              <TableRow key={complaint.id} className="border-border hover:bg-muted/30">
                <TableCell className="font-medium text-foreground">{complaint.plaintiff}</TableCell>
                <TableCell className="text-foreground">{complaint.defendant}</TableCell>
                <TableCell className="text-muted-foreground">{complaint.type}</TableCell>
                <TableCell>
                  <Badge variant="outline" className={getStatusBadge(complaint.status).class}>
                    {complaint.status}
                  </Badge>
                </TableCell>
                <TableCell className="text-muted-foreground">{complaint.date}</TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-1">
                    {complaint.status !== "Resolu" && (
                      <Button 
                        variant="ghost" 
                        size="icon" 
                        className="h-8 w-8 text-emerald-400 hover:text-emerald-300 hover:bg-emerald-500/10"
                        onClick={() => handleResolve(complaint.id)}
                      >
                        <Check className="h-4 w-4" />
                      </Button>
                    )}
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <Eye className="h-4 w-4" />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle className="text-foreground">Deposer une plainte</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Enregistrez une nouvelle plainte dans le systeme.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <label className="text-sm text-muted-foreground">Plaignant</label>
              <Input 
                placeholder="Nom du plaignant" 
                value={newComplaint.plaintiff}
                onChange={(e) => setNewComplaint({ ...newComplaint, plaintiff: e.target.value })}
                className="bg-background border-border"
              />
            </div>
            <div className="grid gap-2">
              <label className="text-sm text-muted-foreground">Accuse</label>
              <Input 
                placeholder="Nom de l'accuse" 
                value={newComplaint.defendant}
                onChange={(e) => setNewComplaint({ ...newComplaint, defendant: e.target.value })}
                className="bg-background border-border"
              />
            </div>
            <div className="grid gap-2">
              <label className="text-sm text-muted-foreground">Type de plainte</label>
              <select 
                value={newComplaint.type}
                onChange={(e) => setNewComplaint({ ...newComplaint, type: e.target.value })}
                className="flex h-10 w-full rounded-md border border-border bg-background px-3 py-2 text-sm text-foreground"
              >
                <option value="Vol">Vol</option>
                <option value="Agression">Agression</option>
                <option value="Vandalisme">Vandalisme</option>
                <option value="Harcelement">Harcelement</option>
                <option value="Autre">Autre</option>
              </select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowAddDialog(false)}>Annuler</Button>
            <Button onClick={handleAddComplaint} className="bg-cyan-600 hover:bg-cyan-700">Deposer</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// Placeholder component for other sections
function PlaceholderContent({ title }: { title: string }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-lg border border-border bg-card p-12 text-center">
      <AlertCircle className="h-12 w-12 text-muted-foreground mb-4" />
      <h2 className="text-xl font-semibold text-foreground mb-2">{title}</h2>
      <p className="text-muted-foreground">Cette section est en cours de developpement.</p>
    </div>
  )
}

export default function Home() {
  const [activeSection, setActiveSection] = useState("dashboard")
  const [notifications] = useState(9)

  const getSectionTitle = () => {
    const titles: Record<string, string> = {
      "dashboard": "Dashboard",
      "mon-compte": "Mon Compte",
      "agent-semaine": "Agent de la semaine",
      "intranet-dea": "INTRANET D.E.A",
      "swat": "SWAT",
      "swat-equipe": "Equipe SWAT",
      "swat-operations": "Operations SWAT",
      "swat-equipement": "Equipement SWAT",
      "sergents": "Sergents",
      "citoyens": "Citoyens",
      "citoyens-liste": "Liste des citoyens",
      "citoyens-recherche": "Recherche citoyens",
      "plaintes": "Plaintes",
      "carnets-probatoires": "Carnets Probatoires",
      "calendrier-formations": "Calendrier des formations",
      "gerer-formations": "Gerer mes formations",
      "dispatch": "Dispatch",
      "logs-patrouilles": "Logs Patrouilles",
      "formations-tierces": "Formations Tierces",
      "formations-externes": "Formations externes",
      "certifications": "Certifications",
      "gestion-formulaires": "Gestion Formulaires",
      "logs-intranet": "Logs Intranet",
    }
    return titles[activeSection] || "Dashboard"
  }

  const renderContent = () => {
    switch (activeSection) {
      case "dashboard":
        return <DashboardContent />
      case "citoyens":
      case "citoyens-liste":
      case "citoyens-recherche":
        return <CitizensContent />
      case "plaintes":
        return <ComplaintsContent />
      default:
        return <PlaceholderContent title={getSectionTitle()} />
    }
  }

  return (
    <div className="flex h-screen bg-background">
      <AppSidebar activeSection={activeSection} onSectionChange={setActiveSection} />
      <div className="flex flex-1 flex-col overflow-hidden">
        {/* Header */}
        <header className="flex h-14 shrink-0 items-center justify-between border-b border-border bg-card px-6">
          <div className="flex items-center gap-3 text-sm text-muted-foreground">
            <X className="h-4 w-4 cursor-pointer hover:text-foreground transition-colors" />
            <span>Intranet</span>
            <span>/</span>
            <span className="text-foreground">{getSectionTitle()}</span>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="sm" className="gap-2 text-pink-400 hover:text-pink-300 hover:bg-pink-400/10">
              <Gift className="h-4 w-4" />
              <span>Ils soutiennent</span>
            </Button>
            
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="h-5 w-5 text-muted-foreground" />
              {notifications > 0 && (
                <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-xs font-bold text-white">
                  {notifications}
                </span>
              )}
            </Button>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="flex items-center gap-2 px-2">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src="/avatars/user.jpg" />
                    <AvatarFallback className="bg-gradient-to-br from-cyan-400 to-emerald-400 text-white text-xs">93</AvatarFallback>
                  </Avatar>
                  <ChevronDown className="h-4 w-4 text-muted-foreground" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 bg-card border-border">
                <DropdownMenuLabel className="text-foreground">Mon Compte</DropdownMenuLabel>
                <DropdownMenuSeparator className="bg-border" />
                <DropdownMenuItem className="gap-2 cursor-pointer" onClick={() => setActiveSection("mon-compte")}>
                  <User className="h-4 w-4" />
                  Profil
                </DropdownMenuItem>
                <DropdownMenuItem className="gap-2 cursor-pointer">
                  <Settings className="h-4 w-4" />
                  Parametres
                </DropdownMenuItem>
                <DropdownMenuSeparator className="bg-border" />
                <DropdownMenuItem className="gap-2 cursor-pointer text-red-400 focus:text-red-400">
                  <LogOut className="h-4 w-4" />
                  Deconnexion
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>
        
        {/* Main content */}
        <main className="flex-1 overflow-auto p-6">
          {renderContent()}
        </main>

        {/* Floating action button */}
        <button 
          className="fixed bottom-6 right-6 flex h-14 w-14 items-center justify-center rounded-full bg-cyan-500 text-white shadow-lg hover:bg-cyan-600 hover:scale-110 transition-all"
          onClick={() => toast.info("Support en cours de developpement")}
        >
          <Coffee className="h-6 w-6" />
        </button>
      </div>
    </div>
  )
}
