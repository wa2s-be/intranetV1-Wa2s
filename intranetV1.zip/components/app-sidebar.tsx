"use client"

import { useState } from "react"
import {
  Home,
  User,
  Award,
  FileText,
  Shield,
  Users,
  ChevronDown,
  AlertTriangle,
  BookOpen,
  Calendar,
  GraduationCap,
  Radio,
  MapPin,
  Layers,
  FileEdit,
  ClipboardList,
  Crown,
} from "lucide-react"
import { cn } from "@/lib/utils"
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip"

interface MenuItem {
  id: string
  title: string
  icon: React.ElementType
  badge?: string
  badgeColor?: string
  children?: { id: string; title: string }[]
}

const menuItems: MenuItem[] = [
  { id: "dashboard", title: "Dashboard", icon: Home },
  { id: "mon-compte", title: "Mon Compte", icon: User },
  { id: "agent-semaine", title: "Agent de la semaine", icon: Award, badge: "Nouveau", badgeColor: "bg-emerald-500" },
  { id: "intranet-dea", title: "INTRANET D.E.A", icon: FileText },
  { 
    id: "swat", 
    title: "SWAT", 
    icon: Shield,
    children: [
      { id: "swat-equipe", title: "Equipe" },
      { id: "swat-operations", title: "Operations" },
      { id: "swat-equipement", title: "Equipement" },
    ]
  },
  { 
    id: "sergents", 
    title: "Sergents", 
    icon: Crown,
    children: [
      { id: "sergents-liste", title: "Liste des sergents" },
      { id: "sergents-grades", title: "Grades" },
    ]
  },
  { 
    id: "citoyens", 
    title: "Citoyens", 
    icon: Users,
    children: [
      { id: "citoyens-liste", title: "Liste des citoyens" },
      { id: "citoyens-recherche", title: "Recherche" },
    ]
  },
  { id: "plaintes", title: "Plaintes", icon: AlertTriangle, badge: "3", badgeColor: "bg-red-500" },
  { id: "carnets-probatoires", title: "Carnets Probatoires", icon: BookOpen },
  { id: "calendrier-formations", title: "Calendrier des formations", icon: Calendar },
  { id: "gerer-formations", title: "Gerer mes formations", icon: GraduationCap },
  { id: "dispatch", title: "Dispatch", icon: Radio },
  { id: "logs-patrouilles", title: "Logs Patrouilles", icon: MapPin },
  { 
    id: "formations-tierces", 
    title: "Formations Tierces", 
    icon: Layers,
    children: [
      { id: "formations-externes", title: "Formations externes" },
      { id: "certifications", title: "Certifications" },
    ]
  },
  { id: "gestion-formulaires", title: "Gestion Formulaires", icon: FileEdit },
  { id: "logs-intranet", title: "Logs Intranet", icon: ClipboardList },
]

interface AppSidebarProps {
  activeSection: string
  onSectionChange: (section: string) => void
}

export function AppSidebar({ activeSection, onSectionChange }: AppSidebarProps) {
  const [expandedItems, setExpandedItems] = useState<string[]>(["swat", "citoyens"])
  const [hoveredItem, setHoveredItem] = useState<string | null>(null)

  const toggleExpanded = (id: string) => {
    setExpandedItems(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    )
  }

  const isActive = (item: MenuItem) => {
    if (activeSection === item.id) return true
    if (item.children) {
      return item.children.some(child => activeSection === child.id)
    }
    return false
  }

  const handleItemClick = (item: MenuItem) => {
    if (item.children) {
      toggleExpanded(item.id)
    } else {
      onSectionChange(item.id)
    }
  }

  return (
    <TooltipProvider delayDuration={300}>
      <aside className="flex h-screen w-64 flex-col bg-[#080d19] border-r border-[#1e3a5f]/50">
        {/* Logo */}
        <div className="flex items-center gap-3 px-4 py-5 border-b border-[#1e3a5f]/50">
          <div className="relative flex h-10 w-10 items-center justify-center">
            <div className="absolute inset-0 rounded-full bg-gradient-to-br from-cyan-400 via-blue-500 to-emerald-400 animate-pulse" />
            <div className="absolute inset-1 rounded-full bg-[#080d19]" />
            <div className="relative h-4 w-4 rounded-full bg-gradient-to-br from-cyan-400 to-emerald-400" />
          </div>
          <div className="flex flex-col">
            <span className="text-sm font-semibold text-white">Intranet</span>
            <span className="text-xs text-red-400">Revolution RP</span>
          </div>
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto py-2 scrollbar-thin scrollbar-track-transparent scrollbar-thumb-[#1e3a5f]">
          <ul className="space-y-0.5 px-2">
            {menuItems.map((item) => (
              <li key={item.id}>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <button
                      onClick={() => handleItemClick(item)}
                      onMouseEnter={() => setHoveredItem(item.id)}
                      onMouseLeave={() => setHoveredItem(null)}
                      className={cn(
                        "group flex w-full items-center justify-between rounded-lg px-3 py-2.5 text-sm transition-all duration-200",
                        isActive(item)
                          ? "bg-blue-600 text-white shadow-lg shadow-blue-600/30"
                          : "text-gray-400 hover:bg-[#1e3a5f]/50 hover:text-white",
                        hoveredItem === item.id && !isActive(item) && "translate-x-1"
                      )}
                    >
                      <div className="flex items-center gap-3">
                        <item.icon className={cn(
                          "h-4 w-4 transition-transform duration-200",
                          hoveredItem === item.id && "scale-110"
                        )} />
                        <span>{item.title}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        {item.badge && (
                          <span className={cn(
                            "px-1.5 py-0.5 text-[10px] font-bold rounded-full text-white",
                            item.badgeColor
                          )}>
                            {item.badge}
                          </span>
                        )}
                        {item.children && (
                          <ChevronDown 
                            className={cn(
                              "h-4 w-4 transition-transform duration-200",
                              expandedItems.includes(item.id) && "rotate-180"
                            )} 
                          />
                        )}
                      </div>
                    </button>
                  </TooltipTrigger>
                  {!item.children && (
                    <TooltipContent side="right" className="bg-[#1e3a5f] border-[#1e3a5f] text-white">
                      <p>{item.title}</p>
                    </TooltipContent>
                  )}
                </Tooltip>
                
                {/* Submenu */}
                {item.children && expandedItems.includes(item.id) && (
                  <ul className="mt-1 ml-4 space-y-0.5 border-l-2 border-[#1e3a5f]/50 pl-3 overflow-hidden animate-in slide-in-from-top-2 duration-200">
                    {item.children.map((child) => (
                      <li key={child.id}>
                        <button
                          onClick={() => onSectionChange(child.id)}
                          className={cn(
                            "flex w-full items-center rounded-md px-3 py-2 text-sm transition-all duration-200",
                            activeSection === child.id
                              ? "bg-blue-600/50 text-white"
                              : "text-gray-500 hover:bg-[#1e3a5f]/30 hover:text-gray-300 hover:translate-x-1"
                          )}
                        >
                          <span className={cn(
                            "w-1.5 h-1.5 rounded-full mr-3 transition-all",
                            activeSection === child.id 
                              ? "bg-cyan-400" 
                              : "bg-gray-600"
                          )} />
                          {child.title}
                        </button>
                      </li>
                    ))}
                  </ul>
                )}
              </li>
            ))}
          </ul>
        </nav>

        {/* Footer */}
        <div className="border-t border-[#1e3a5f]/50 p-4">
          <div className="flex items-center gap-3 rounded-lg bg-[#1e3a5f]/30 p-3 transition-colors hover:bg-[#1e3a5f]/50 cursor-pointer">
            <div className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-cyan-400 to-emerald-400">
              <span className="text-xs font-bold text-white">93</span>
            </div>
            <div className="flex flex-col">
              <span className="text-xs font-medium text-white">Agent 93</span>
              <span className="text-[10px] text-emerald-400 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                En ligne
              </span>
            </div>
          </div>
        </div>
      </aside>
    </TooltipProvider>
  )
}
