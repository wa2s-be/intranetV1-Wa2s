"use client"

import { useState } from "react"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Search,
  Plus,
  MoreHorizontal,
  Pencil,
  Trash2,
  Eye,
  Download,
  ArrowUpDown,
} from "lucide-react"

// Types
interface Employee {
  id: string
  nom: string
  prenom: string
  email: string
  departement: string
  poste: string
  statut: "Actif" | "Inactif" | "Conge"
  dateEmbauche: string
}

interface Document {
  id: string
  titre: string
  type: string
  auteur: string
  dateCreation: string
  taille: string
  statut: "Publie" | "Brouillon" | "Archive"
}

interface Projet {
  id: string
  nom: string
  responsable: string
  dateDebut: string
  dateFin: string
  budget: string
  progression: number
  statut: "En cours" | "Termine" | "En attente" | "Annule"
}

interface Evenement {
  id: string
  titre: string
  date: string
  heure: string
  lieu: string
  organisateur: string
  participants: number
  type: "Reunion" | "Formation" | "Evenement" | "Autre"
}

interface Message {
  id: string
  expediteur: string
  sujet: string
  date: string
  lu: boolean
  priorite: "Haute" | "Normale" | "Basse"
}

interface Departement {
  id: string
  nom: string
  responsable: string
  effectif: number
  budget: string
  localisation: string
}

// Sample data
const employeesData: Employee[] = [
  { id: "1", nom: "Martin", prenom: "Jean", email: "j.martin@wa2s.fr", departement: "IT", poste: "Developpeur Senior", statut: "Actif", dateEmbauche: "2020-03-15" },
  { id: "2", nom: "Dubois", prenom: "Marie", email: "m.dubois@wa2s.fr", departement: "RH", poste: "Responsable RH", statut: "Actif", dateEmbauche: "2018-06-01" },
  { id: "3", nom: "Bernard", prenom: "Pierre", email: "p.bernard@wa2s.fr", departement: "Finance", poste: "Comptable", statut: "Conge", dateEmbauche: "2019-09-10" },
  { id: "4", nom: "Petit", prenom: "Sophie", email: "s.petit@wa2s.fr", departement: "Marketing", poste: "Chef de projet", statut: "Actif", dateEmbauche: "2021-01-20" },
  { id: "5", nom: "Leroy", prenom: "Thomas", email: "t.leroy@wa2s.fr", departement: "IT", poste: "Developpeur Junior", statut: "Actif", dateEmbauche: "2023-02-14" },
  { id: "6", nom: "Moreau", prenom: "Claire", email: "c.moreau@wa2s.fr", departement: "Commercial", poste: "Commercial", statut: "Inactif", dateEmbauche: "2017-11-30" },
]

const documentsData: Document[] = [
  { id: "1", titre: "Politique de securite 2024", type: "PDF", auteur: "Admin", dateCreation: "2024-01-15", taille: "2.4 MB", statut: "Publie" },
  { id: "2", titre: "Manuel employe", type: "DOCX", auteur: "RH", dateCreation: "2024-02-20", taille: "1.8 MB", statut: "Publie" },
  { id: "3", titre: "Rapport financier Q1", type: "XLSX", auteur: "Finance", dateCreation: "2024-03-31", taille: "3.2 MB", statut: "Brouillon" },
  { id: "4", titre: "Presentation produit", type: "PPTX", auteur: "Marketing", dateCreation: "2024-04-10", taille: "5.6 MB", statut: "Publie" },
  { id: "5", titre: "Contrat fournisseur", type: "PDF", auteur: "Legal", dateCreation: "2024-04-15", taille: "890 KB", statut: "Archive" },
]

const projetsData: Projet[] = [
  { id: "1", nom: "Refonte site web", responsable: "Jean Martin", dateDebut: "2024-01-01", dateFin: "2024-06-30", budget: "50 000 EUR", progression: 75, statut: "En cours" },
  { id: "2", nom: "Migration cloud", responsable: "Thomas Leroy", dateDebut: "2024-03-15", dateFin: "2024-09-30", budget: "120 000 EUR", progression: 30, statut: "En cours" },
  { id: "3", nom: "App mobile", responsable: "Sophie Petit", dateDebut: "2024-02-01", dateFin: "2024-05-31", budget: "80 000 EUR", progression: 100, statut: "Termine" },
  { id: "4", nom: "CRM Implementation", responsable: "Marie Dubois", dateDebut: "2024-05-01", dateFin: "2024-12-31", budget: "200 000 EUR", progression: 10, statut: "En attente" },
]

const evenementsData: Evenement[] = [
  { id: "1", titre: "Reunion equipe IT", date: "2024-04-20", heure: "10:00", lieu: "Salle A", organisateur: "Jean Martin", participants: 8, type: "Reunion" },
  { id: "2", titre: "Formation securite", date: "2024-04-22", heure: "14:00", lieu: "Salle de conf.", organisateur: "Admin", participants: 25, type: "Formation" },
  { id: "3", titre: "Team building", date: "2024-04-25", heure: "09:00", lieu: "Exterieur", organisateur: "RH", participants: 50, type: "Evenement" },
  { id: "4", titre: "Review projet Q2", date: "2024-04-30", heure: "11:00", lieu: "Salle B", organisateur: "Direction", participants: 12, type: "Reunion" },
]

const messagesData: Message[] = [
  { id: "1", expediteur: "Direction", sujet: "Nouvelle politique teletravail", date: "2024-04-18", lu: false, priorite: "Haute" },
  { id: "2", expediteur: "RH", sujet: "Rappel: Entretiens annuels", date: "2024-04-17", lu: true, priorite: "Normale" },
  { id: "3", expediteur: "IT", sujet: "Maintenance serveur ce weekend", date: "2024-04-16", lu: true, priorite: "Normale" },
  { id: "4", expediteur: "Finance", sujet: "Notes de frais - Deadline", date: "2024-04-15", lu: false, priorite: "Haute" },
  { id: "5", expediteur: "Marketing", sujet: "Nouvelle campagne - Feedback", date: "2024-04-14", lu: true, priorite: "Basse" },
]

const departementsData: Departement[] = [
  { id: "1", nom: "IT", responsable: "Jean Martin", effectif: 15, budget: "500 000 EUR", localisation: "Batiment A - 2eme etage" },
  { id: "2", nom: "Ressources Humaines", responsable: "Marie Dubois", effectif: 8, budget: "200 000 EUR", localisation: "Batiment A - 1er etage" },
  { id: "3", nom: "Finance", responsable: "Pierre Bernard", effectif: 12, budget: "150 000 EUR", localisation: "Batiment B - RDC" },
  { id: "4", nom: "Marketing", responsable: "Sophie Petit", effectif: 10, budget: "350 000 EUR", localisation: "Batiment A - 3eme etage" },
  { id: "5", nom: "Commercial", responsable: "Claire Moreau", effectif: 20, budget: "450 000 EUR", localisation: "Batiment C - 1er etage" },
]

// Helper function for status badges
function getStatusBadge(statut: string) {
  const variants: Record<string, "default" | "secondary" | "destructive" | "outline"> = {
    "Actif": "default",
    "Inactif": "destructive",
    "Conge": "secondary",
    "Publie": "default",
    "Brouillon": "secondary",
    "Archive": "outline",
    "En cours": "default",
    "Termine": "secondary",
    "En attente": "outline",
    "Annule": "destructive",
  }
  return <Badge variant={variants[statut] || "default"}>{statut}</Badge>
}

function getPriorityBadge(priorite: string) {
  const variants: Record<string, "default" | "secondary" | "destructive"> = {
    "Haute": "destructive",
    "Normale": "default",
    "Basse": "secondary",
  }
  return <Badge variant={variants[priorite] || "default"}>{priorite}</Badge>
}

// Table Header Component
function TableActions({ 
  searchTerm, 
  setSearchTerm, 
  onAdd,
  addLabel = "Ajouter"
}: { 
  searchTerm: string
  setSearchTerm: (term: string) => void
  onAdd?: () => void
  addLabel?: string
}) {
  return (
    <div className="flex items-center justify-between gap-4 mb-4">
      <div className="relative flex-1 max-w-sm">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          placeholder="Rechercher..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="pl-10"
        />
      </div>
      {onAdd && (
        <Button onClick={onAdd} size="sm">
          <Plus className="h-4 w-4 mr-2" />
          {addLabel}
        </Button>
      )}
    </div>
  )
}

// Row Actions Dropdown
function RowActions({ onView, onEdit, onDelete }: { onView?: () => void; onEdit?: () => void; onDelete?: () => void }) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <MoreHorizontal className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {onView && (
          <DropdownMenuItem onClick={onView}>
            <Eye className="h-4 w-4 mr-2" />
            Voir
          </DropdownMenuItem>
        )}
        {onEdit && (
          <DropdownMenuItem onClick={onEdit}>
            <Pencil className="h-4 w-4 mr-2" />
            Modifier
          </DropdownMenuItem>
        )}
        {onDelete && (
          <DropdownMenuItem onClick={onDelete} className="text-destructive">
            <Trash2 className="h-4 w-4 mr-2" />
            Supprimer
          </DropdownMenuItem>
        )}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}

// Employees Table
export function EmployeesTable() {
  const [searchTerm, setSearchTerm] = useState("")
  const [employees, setEmployees] = useState(employeesData)
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false)

  const filteredEmployees = employees.filter(emp =>
    emp.nom.toLowerCase().includes(searchTerm.toLowerCase()) ||
    emp.prenom.toLowerCase().includes(searchTerm.toLowerCase()) ||
    emp.departement.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <div>
      <TableActions 
        searchTerm={searchTerm} 
        setSearchTerm={setSearchTerm} 
        onAdd={() => setIsAddDialogOpen(true)}
        addLabel="Nouvel employe"
      />
      <div className="rounded-lg border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nom</TableHead>
              <TableHead>Prenom</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Departement</TableHead>
              <TableHead>Poste</TableHead>
              <TableHead>Statut</TableHead>
              <TableHead>Date embauche</TableHead>
              <TableHead className="w-[50px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredEmployees.map((employee) => (
              <TableRow key={employee.id}>
                <TableCell className="font-medium">{employee.nom}</TableCell>
                <TableCell>{employee.prenom}</TableCell>
                <TableCell>{employee.email}</TableCell>
                <TableCell>{employee.departement}</TableCell>
                <TableCell>{employee.poste}</TableCell>
                <TableCell>{getStatusBadge(employee.statut)}</TableCell>
                <TableCell>{new Date(employee.dateEmbauche).toLocaleDateString('fr-FR')}</TableCell>
                <TableCell>
                  <RowActions 
                    onView={() => alert(`Voir ${employee.prenom} ${employee.nom}`)}
                    onEdit={() => alert(`Modifier ${employee.prenom} ${employee.nom}`)}
                    onDelete={() => setEmployees(employees.filter(e => e.id !== employee.id))}
                  />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Ajouter un employe</DialogTitle>
            <DialogDescription>Remplissez les informations du nouvel employe.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="nom">Nom</Label>
                <Input id="nom" placeholder="Nom" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="prenom">Prenom</Label>
                <Input id="prenom" placeholder="Prenom" />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" placeholder="email@wa2s.fr" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="departement">Departement</Label>
                <Select>
                  <SelectTrigger>
                    <SelectValue placeholder="Choisir" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="it">IT</SelectItem>
                    <SelectItem value="rh">RH</SelectItem>
                    <SelectItem value="finance">Finance</SelectItem>
                    <SelectItem value="marketing">Marketing</SelectItem>
                    <SelectItem value="commercial">Commercial</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="poste">Poste</Label>
                <Input id="poste" placeholder="Poste" />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>Annuler</Button>
            <Button onClick={() => setIsAddDialogOpen(false)}>Ajouter</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

// Documents Table
export function DocumentsTable() {
  const [searchTerm, setSearchTerm] = useState("")
  const [documents, setDocuments] = useState(documentsData)

  const filteredDocuments = documents.filter(doc =>
    doc.titre.toLowerCase().includes(searchTerm.toLowerCase()) ||
    doc.auteur.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <div>
      <TableActions 
        searchTerm={searchTerm} 
        setSearchTerm={setSearchTerm} 
        onAdd={() => alert("Ajouter document")}
        addLabel="Nouveau document"
      />
      <div className="rounded-lg border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Titre</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Auteur</TableHead>
              <TableHead>Date creation</TableHead>
              <TableHead>Taille</TableHead>
              <TableHead>Statut</TableHead>
              <TableHead className="w-[50px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredDocuments.map((document) => (
              <TableRow key={document.id}>
                <TableCell className="font-medium">{document.titre}</TableCell>
                <TableCell>
                  <Badge variant="outline">{document.type}</Badge>
                </TableCell>
                <TableCell>{document.auteur}</TableCell>
                <TableCell>{new Date(document.dateCreation).toLocaleDateString('fr-FR')}</TableCell>
                <TableCell>{document.taille}</TableCell>
                <TableCell>{getStatusBadge(document.statut)}</TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem>
                        <Eye className="h-4 w-4 mr-2" />
                        Apercu
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Download className="h-4 w-4 mr-2" />
                        Telecharger
                      </DropdownMenuItem>
                      <DropdownMenuItem>
                        <Pencil className="h-4 w-4 mr-2" />
                        Modifier
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        className="text-destructive"
                        onClick={() => setDocuments(documents.filter(d => d.id !== document.id))}
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Supprimer
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

// Projects Table
export function ProjetsTable() {
  const [searchTerm, setSearchTerm] = useState("")
  const [projets, setProjets] = useState(projetsData)

  const filteredProjets = projets.filter(proj =>
    proj.nom.toLowerCase().includes(searchTerm.toLowerCase()) ||
    proj.responsable.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <div>
      <TableActions 
        searchTerm={searchTerm} 
        setSearchTerm={setSearchTerm} 
        onAdd={() => alert("Ajouter projet")}
        addLabel="Nouveau projet"
      />
      <div className="rounded-lg border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nom du projet</TableHead>
              <TableHead>Responsable</TableHead>
              <TableHead>Date debut</TableHead>
              <TableHead>Date fin</TableHead>
              <TableHead>Budget</TableHead>
              <TableHead>Progression</TableHead>
              <TableHead>Statut</TableHead>
              <TableHead className="w-[50px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredProjets.map((projet) => (
              <TableRow key={projet.id}>
                <TableCell className="font-medium">{projet.nom}</TableCell>
                <TableCell>{projet.responsable}</TableCell>
                <TableCell>{new Date(projet.dateDebut).toLocaleDateString('fr-FR')}</TableCell>
                <TableCell>{new Date(projet.dateFin).toLocaleDateString('fr-FR')}</TableCell>
                <TableCell>{projet.budget}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <div className="h-2 w-20 rounded-full bg-muted">
                      <div 
                        className="h-2 rounded-full bg-primary" 
                        style={{ width: `${projet.progression}%` }}
                      />
                    </div>
                    <span className="text-sm text-muted-foreground">{projet.progression}%</span>
                  </div>
                </TableCell>
                <TableCell>{getStatusBadge(projet.statut)}</TableCell>
                <TableCell>
                  <RowActions 
                    onView={() => alert(`Voir projet: ${projet.nom}`)}
                    onEdit={() => alert(`Modifier projet: ${projet.nom}`)}
                    onDelete={() => setProjets(projets.filter(p => p.id !== projet.id))}
                  />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

// Calendar/Events Table
export function CalendrierTable() {
  const [searchTerm, setSearchTerm] = useState("")
  const [evenements, setEvenements] = useState(evenementsData)

  const filteredEvenements = evenements.filter(evt =>
    evt.titre.toLowerCase().includes(searchTerm.toLowerCase()) ||
    evt.organisateur.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const getTypeBadge = (type: string) => {
    const colors: Record<string, "default" | "secondary" | "outline"> = {
      "Reunion": "default",
      "Formation": "secondary",
      "Evenement": "outline",
      "Autre": "outline",
    }
    return <Badge variant={colors[type] || "default"}>{type}</Badge>
  }

  return (
    <div>
      <TableActions 
        searchTerm={searchTerm} 
        setSearchTerm={setSearchTerm} 
        onAdd={() => alert("Ajouter evenement")}
        addLabel="Nouvel evenement"
      />
      <div className="rounded-lg border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Titre</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Heure</TableHead>
              <TableHead>Lieu</TableHead>
              <TableHead>Organisateur</TableHead>
              <TableHead>Participants</TableHead>
              <TableHead>Type</TableHead>
              <TableHead className="w-[50px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredEvenements.map((evenement) => (
              <TableRow key={evenement.id}>
                <TableCell className="font-medium">{evenement.titre}</TableCell>
                <TableCell>{new Date(evenement.date).toLocaleDateString('fr-FR')}</TableCell>
                <TableCell>{evenement.heure}</TableCell>
                <TableCell>{evenement.lieu}</TableCell>
                <TableCell>{evenement.organisateur}</TableCell>
                <TableCell>{evenement.participants}</TableCell>
                <TableCell>{getTypeBadge(evenement.type)}</TableCell>
                <TableCell>
                  <RowActions 
                    onView={() => alert(`Voir evenement: ${evenement.titre}`)}
                    onEdit={() => alert(`Modifier evenement: ${evenement.titre}`)}
                    onDelete={() => setEvenements(evenements.filter(e => e.id !== evenement.id))}
                  />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

// Messages Table
export function MessagesTable() {
  const [searchTerm, setSearchTerm] = useState("")
  const [messages, setMessages] = useState(messagesData)

  const filteredMessages = messages.filter(msg =>
    msg.sujet.toLowerCase().includes(searchTerm.toLowerCase()) ||
    msg.expediteur.toLowerCase().includes(searchTerm.toLowerCase())
  )

  const toggleRead = (id: string) => {
    setMessages(messages.map(msg => 
      msg.id === id ? { ...msg, lu: !msg.lu } : msg
    ))
  }

  return (
    <div>
      <TableActions 
        searchTerm={searchTerm} 
        setSearchTerm={setSearchTerm} 
        onAdd={() => alert("Nouveau message")}
        addLabel="Nouveau message"
      />
      <div className="rounded-lg border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="w-[30px]"></TableHead>
              <TableHead>Expediteur</TableHead>
              <TableHead>Sujet</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Priorite</TableHead>
              <TableHead className="w-[50px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredMessages.map((message) => (
              <TableRow key={message.id} className={!message.lu ? "bg-muted/30" : ""}>
                <TableCell>
                  <div 
                    className={`h-2 w-2 rounded-full ${!message.lu ? "bg-primary" : "bg-transparent"}`}
                  />
                </TableCell>
                <TableCell className={!message.lu ? "font-semibold" : ""}>{message.expediteur}</TableCell>
                <TableCell className={!message.lu ? "font-semibold" : ""}>{message.sujet}</TableCell>
                <TableCell>{new Date(message.date).toLocaleDateString('fr-FR')}</TableCell>
                <TableCell>{getPriorityBadge(message.priorite)}</TableCell>
                <TableCell>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreHorizontal className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => alert(`Lire: ${message.sujet}`)}>
                        <Eye className="h-4 w-4 mr-2" />
                        Lire
                      </DropdownMenuItem>
                      <DropdownMenuItem onClick={() => toggleRead(message.id)}>
                        {message.lu ? "Marquer non lu" : "Marquer lu"}
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        className="text-destructive"
                        onClick={() => setMessages(messages.filter(m => m.id !== message.id))}
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Supprimer
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}

// Departments Table
export function DepartementsTable() {
  const [searchTerm, setSearchTerm] = useState("")
  const [departements, setDepartements] = useState(departementsData)

  const filteredDepartements = departements.filter(dept =>
    dept.nom.toLowerCase().includes(searchTerm.toLowerCase()) ||
    dept.responsable.toLowerCase().includes(searchTerm.toLowerCase())
  )

  return (
    <div>
      <TableActions 
        searchTerm={searchTerm} 
        setSearchTerm={setSearchTerm} 
        onAdd={() => alert("Ajouter departement")}
        addLabel="Nouveau departement"
      />
      <div className="rounded-lg border bg-card">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Departement</TableHead>
              <TableHead>Responsable</TableHead>
              <TableHead>Effectif</TableHead>
              <TableHead>Budget</TableHead>
              <TableHead>Localisation</TableHead>
              <TableHead className="w-[50px]"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {filteredDepartements.map((departement) => (
              <TableRow key={departement.id}>
                <TableCell className="font-medium">{departement.nom}</TableCell>
                <TableCell>{departement.responsable}</TableCell>
                <TableCell>{departement.effectif} personnes</TableCell>
                <TableCell>{departement.budget}</TableCell>
                <TableCell>{departement.localisation}</TableCell>
                <TableCell>
                  <RowActions 
                    onView={() => alert(`Voir departement: ${departement.nom}`)}
                    onEdit={() => alert(`Modifier departement: ${departement.nom}`)}
                    onDelete={() => setDepartements(departements.filter(d => d.id !== departement.id))}
                  />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  )
}
