"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import {
  Users,
  FileText,
  FolderOpen,
  Calendar,
  MessageSquare,
  Bell,
  Clock,
  ArrowRight,
} from "lucide-react"

const recentActivities = [
  { id: 1, type: "document", message: "Nouveau document ajoute: Rapport Q1 2024", time: "Il y a 2h", user: "JM" },
  { id: 2, type: "employee", message: "Thomas Leroy a rejoint l equipe IT", time: "Il y a 4h", user: "RH" },
  { id: 3, type: "project", message: "Projet App mobile marque comme termine", time: "Il y a 6h", user: "SP" },
  { id: 4, type: "event", message: "Reunion equipe IT planifiee pour demain", time: "Il y a 8h", user: "JM" },
  { id: 5, type: "message", message: "Nouvelle politique teletravail publiee", time: "Hier", user: "DR" },
]

const upcomingEvents = [
  { id: 1, title: "Reunion equipe IT", date: "20 Avr", time: "10:00", type: "Reunion" },
  { id: 2, title: "Formation securite", date: "22 Avr", time: "14:00", type: "Formation" },
  { id: 3, title: "Team building", date: "25 Avr", time: "09:00", type: "Evenement" },
]

const quickStats = [
  { label: "Employes", value: "62", icon: Users, color: "bg-sky-100 text-sky-600" },
  { label: "Documents", value: "220", icon: FileText, color: "bg-emerald-100 text-emerald-600" },
  { label: "Projets", value: "15", icon: FolderOpen, color: "bg-amber-100 text-amber-600" },
  { label: "Messages", value: "5", icon: MessageSquare, color: "bg-rose-100 text-rose-600" },
]

interface HomeDashboardProps {
  onNavigate: (section: string) => void
}

export function HomeDashboard({ onNavigate }: HomeDashboardProps) {
  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h2 className="text-2xl font-bold tracking-tight">Bienvenue sur intranetV1 Wa2s</h2>
          <p className="text-muted-foreground">
            Voici un apercu de votre espace de travail
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" size="sm">
            <Bell className="h-4 w-4 mr-2" />
            Notifications
            <Badge variant="destructive" className="ml-2">3</Badge>
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {quickStats.map((stat, index) => (
          <Card key={index} className="cursor-pointer transition-shadow hover:shadow-md" onClick={() => {
            const routes: Record<string, string> = {
              "Employes": "employes",
              "Documents": "documents",
              "Projets": "projets",
              "Messages": "messages",
            }
            onNavigate(routes[stat.label] || "accueil")
          }}>
            <CardContent className="flex items-center gap-4 p-6">
              <div className={`flex h-12 w-12 items-center justify-center rounded-lg ${stat.color}`}>
                <stat.icon className="h-6 w-6" />
              </div>
              <div>
                <p className="text-2xl font-bold">{stat.value}</p>
                <p className="text-sm text-muted-foreground">{stat.label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Recent Activities */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Activites recentes</CardTitle>
              <CardDescription>Les dernieres actions sur la plateforme</CardDescription>
            </div>
            <Button variant="ghost" size="sm">
              Voir tout
              <ArrowRight className="h-4 w-4 ml-1" />
            </Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivities.map((activity) => (
                <div key={activity.id} className="flex items-start gap-3">
                  <Avatar className="h-8 w-8">
                    <AvatarFallback className="text-xs">{activity.user}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 space-y-1">
                    <p className="text-sm">{activity.message}</p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {activity.time}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Upcoming Events */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Evenements a venir</CardTitle>
              <CardDescription>Vos prochains rendez-vous</CardDescription>
            </div>
            <Button variant="ghost" size="sm" onClick={() => onNavigate("calendrier")}>
              Calendrier
              <ArrowRight className="h-4 w-4 ml-1" />
            </Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {upcomingEvents.map((event) => (
                <div key={event.id} className="flex items-center gap-4 rounded-lg border p-3">
                  <div className="flex h-12 w-12 flex-col items-center justify-center rounded-lg bg-primary/10 text-primary">
                    <span className="text-xs font-medium">{event.date.split(' ')[1]}</span>
                    <span className="text-lg font-bold leading-none">{event.date.split(' ')[0]}</span>
                  </div>
                  <div className="flex-1">
                    <p className="font-medium">{event.title}</p>
                    <p className="text-sm text-muted-foreground flex items-center gap-2">
                      <Clock className="h-3 w-3" />
                      {event.time}
                      <Badge variant="outline" className="ml-2">{event.type}</Badge>
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Actions rapides</CardTitle>
          <CardDescription>Acces direct aux fonctionnalites principales</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <Button variant="outline" className="h-auto flex-col gap-2 py-4" onClick={() => onNavigate("employes")}>
              <Users className="h-6 w-6" />
              <span>Ajouter un employe</span>
            </Button>
            <Button variant="outline" className="h-auto flex-col gap-2 py-4" onClick={() => onNavigate("documents")}>
              <FileText className="h-6 w-6" />
              <span>Creer un document</span>
            </Button>
            <Button variant="outline" className="h-auto flex-col gap-2 py-4" onClick={() => onNavigate("projets")}>
              <FolderOpen className="h-6 w-6" />
              <span>Nouveau projet</span>
            </Button>
            <Button variant="outline" className="h-auto flex-col gap-2 py-4" onClick={() => onNavigate("calendrier")}>
              <Calendar className="h-6 w-6" />
              <span>Planifier evenement</span>
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
