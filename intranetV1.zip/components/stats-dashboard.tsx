"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Users, FileText, FolderOpen, TrendingUp, TrendingDown, Calendar } from "lucide-react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  LineChart,
  Line,
  PieChart,
  Pie,
  Cell,
} from "recharts"

const monthlyData = [
  { name: "Jan", employes: 45, documents: 120, projets: 8 },
  { name: "Fev", employes: 48, documents: 145, projets: 10 },
  { name: "Mar", employes: 52, documents: 160, projets: 12 },
  { name: "Avr", employes: 55, documents: 180, projets: 11 },
  { name: "Mai", employes: 58, documents: 200, projets: 14 },
  { name: "Juin", employes: 62, documents: 220, projets: 15 },
]

const departmentData = [
  { name: "IT", value: 15, color: "#0ea5e9" },
  { name: "RH", value: 8, color: "#22c55e" },
  { name: "Finance", value: 12, color: "#f59e0b" },
  { name: "Marketing", value: 10, color: "#ef4444" },
  { name: "Commercial", value: 20, color: "#8b5cf6" },
]

const projectStatusData = [
  { name: "En cours", value: 8, color: "#0ea5e9" },
  { name: "Termine", value: 12, color: "#22c55e" },
  { name: "En attente", value: 4, color: "#f59e0b" },
  { name: "Annule", value: 2, color: "#ef4444" },
]

export function StatsDashboard() {
  const stats = [
    {
      title: "Total Employes",
      value: "62",
      change: "+7%",
      trend: "up",
      icon: Users,
      description: "depuis le mois dernier",
    },
    {
      title: "Documents",
      value: "220",
      change: "+10%",
      trend: "up",
      icon: FileText,
      description: "documents actifs",
    },
    {
      title: "Projets actifs",
      value: "15",
      change: "+7%",
      trend: "up",
      icon: FolderOpen,
      description: "projets en cours",
    },
    {
      title: "Evenements",
      value: "8",
      change: "-2",
      trend: "down",
      icon: Calendar,
      description: "ce mois-ci",
    },
  ]

  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat, index) => (
          <Card key={index}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">{stat.title}</CardTitle>
              <stat.icon className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
              <p className="text-xs text-muted-foreground flex items-center gap-1">
                {stat.trend === "up" ? (
                  <TrendingUp className="h-3 w-3 text-green-500" />
                ) : (
                  <TrendingDown className="h-3 w-3 text-red-500" />
                )}
                <span className={stat.trend === "up" ? "text-green-500" : "text-red-500"}>
                  {stat.change}
                </span>
                {stat.description}
              </p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts */}
      <div className="grid gap-4 md:grid-cols-2">
        {/* Monthly Evolution */}
        <Card>
          <CardHeader>
            <CardTitle>Evolution mensuelle</CardTitle>
            <CardDescription>Croissance des employes et documents</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="name" className="text-xs" />
                <YAxis className="text-xs" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                />
                <Line 
                  type="monotone" 
                  dataKey="employes" 
                  stroke="#0ea5e9" 
                  strokeWidth={2}
                  name="Employes"
                />
                <Line 
                  type="monotone" 
                  dataKey="projets" 
                  stroke="#22c55e" 
                  strokeWidth={2}
                  name="Projets"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Documents by Month */}
        <Card>
          <CardHeader>
            <CardTitle>Documents par mois</CardTitle>
            <CardDescription>Nombre de documents crees</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-muted" />
                <XAxis dataKey="name" className="text-xs" />
                <YAxis className="text-xs" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                />
                <Bar dataKey="documents" fill="#0ea5e9" radius={[4, 4, 0, 0]} name="Documents" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Department Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Repartition par departement</CardTitle>
            <CardDescription>Effectif par departement</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={departmentData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={2}
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}`}
                >
                  {departmentData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Project Status */}
        <Card>
          <CardHeader>
            <CardTitle>Statut des projets</CardTitle>
            <CardDescription>Repartition par statut</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={projectStatusData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={100}
                  paddingAngle={2}
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}`}
                >
                  {projectStatusData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'hsl(var(--card))', 
                    border: '1px solid hsl(var(--border))',
                    borderRadius: '8px'
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
